# MiniGPT

MiniGPT is a simple Python library for answering questions using AI-like behavior. 4 type of AI
# Installation

```bash
pip install MiniGPT
```
# Usage

import MiniGPT
print(MiniGPT.duckduck("What is AI?"))