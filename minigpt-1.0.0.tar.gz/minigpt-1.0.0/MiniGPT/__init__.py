from .duckgo import duckduck
from .blackb import blackbox
from .powerbrainai import powerai
from .binjiefun import binjfun